import boto3
from datetime import datetime

def lambda_handler(event, context):
    sfn_name = 'cicd_workflow_state_machine'

    try:
        sfn_client = boto3.client('stepfunctions')
        sfn_response = sfn_client.list_state_machines()

        sfn_arn = [sf['stateMachineArn'] for sf in sfn_response['stateMachines'] if sfn_name in sf['stateMachineArn']]

        if len(sfn_arn) > 0:
            state_machine_arn = sfn_arn[0]

            print(f"The ARN of the step function is {state_machine_arn}")

            response = sfn_client.start_execution(
                stateMachineArn=state_machine_arn
                # name='MyExecution2',  # 给执行一个名称，可选参数
                # input='{}'  # 指定输入数据，可选参数
            )
            
            # 将结果中的 datetime 对象转换为字符串
            response['startDate'] = response['startDate'].isoformat()

            return response
        else:
            print("There is no related step function")

    except Exception as e:
        print(f"An error occurred: {e}")
        raise e