import boto3

 

def lambda_handler(event, context):

    # 创建Step Functions客户端

    client = boto3.client('stepfunctions')

 

    # 定义要调用的Step Functions状态机ARN

    state_machine_arn = 'arn:aws:states:ap-northeast-1:213903534337:stateMachine:cedc-sfn-workflow-state-machine-mc'

 

    try:

        # 调用Step Functions开始执行

        response = client.start_execution(

            stateMachineArn=state_machine_arn,

            input='{}'

        )

        execution_arn = response['executionArn']

        print(f'Step Functions execution started: {execution_arn}')


        # 处理响应或执行其他操作


    except Exception as e:

        print(f'Error calling Step Functions: {str(e)}')