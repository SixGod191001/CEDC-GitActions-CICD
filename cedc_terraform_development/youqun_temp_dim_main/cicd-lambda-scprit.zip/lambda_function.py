import boto3

def lambda_handler(event, context):
    state_machine_name = "cedc-sfn-workflow-state-machine-mc"  # Step Functions状态机的名称

    # 使用状态机名称获取状态机的ARN
    stepfunctions_client = boto3.client('stepfunctions')
    response = stepfunctions_client.list_state_machines()
    state_machines = response['stateMachines']
    state_machine_arn = None

    for state_machine in state_machines:
        if state_machine['name'] == state_machine_name:
            state_machine_arn = state_machine['stateMachineArn']
            break

    if not state_machine_arn:
        return {
            'statusCode': 400,
            'body': 'Could not find the specified Step Functions state machine.'
        }

    # 使用state_machine_arn调用Step Functions
    response = stepfunctions_client.start_execution(
        stateMachineArn=state_machine_arn,
        # 其他参数...
        # ...
    )

    return {
        'statusCode': 200,
        'body': 'Step Functions execution started.'
    }