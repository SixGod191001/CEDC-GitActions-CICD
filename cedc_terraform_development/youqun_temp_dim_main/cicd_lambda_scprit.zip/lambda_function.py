import boto3


def lambda_handler(event, context):
    sfn_name = 'cicd_workflow_state_machine'

    sfn_client = boto3.client('stepfunctions')
    sfn_response = sfn_client.list_state_machines()
    sfn_arn = [sf['stateMachineArn'] for sf in sfn_response['stateMachines'] if sf['stateMachineArn'].__contains__(sfn_name)]

    if len(sfn_arn) > 0:
        state_machine_arn = sfn_arn[0]
        print(f"The arn of the step function is {sfn_arn[0]}")

        response = sfn_client.start_execution(
            stateMachineArn=state_machine_arn
            # name='MyExecution2',  # 给执行一个名称，可选参数
            # input='{}'  # 指定输入数据，可选参数
        )
        return response
    else:
        print("There is no related step function")